const express = require("express");

const router = express.Router();

// This endpoint is intentionally harmless and only mounted in development.
router.get("/ping", (_req, res) => {
  res.status(200).json({ ok: true, environment: "development" });
});

const mountTestRoutes = (app, environment = process.env.NODE_ENV) => {
  if (environment !== "development") return false;

  app.use("/api/v1/test", router);
  return true;
};

module.exports = { router, mountTestRoutes };
