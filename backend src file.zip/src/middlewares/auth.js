const jwt = require("jsonwebtoken");
const User = require("../models/users");

const userAuth = async (req, res, next) => {
  try {
    const cookies = req.cookies;

    const token =
      cookies.token || req.header("Authorization")?.replace("Bearer ", "");

    if (!token) {
      throw new Error("Token is missing");
    }

    const decodedObj = jwt.verify(token, process.env.JWT_SECRET);
    const { _id } = decodedObj;

    const user = await User.findById(_id);
    if (!user) {
      throw new Error("User not found");
    }

    req.user = user;
    next();
  } catch (err) {
    res.status(401).json({ error: "Unauthorized" });
  }
};

const allowRoles = (roles = []) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Forbidden - insufficient role" });
    }
    next();
  };
};

module.exports = {
  userAuth,
  allowRoles,
};
